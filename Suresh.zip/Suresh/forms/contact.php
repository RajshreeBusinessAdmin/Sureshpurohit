<?php


// Load Composer's autoloader or manually include the files
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../src/PHPMailer.php';
require '../src/SMTP.php';
require '../src/Exception.php';

$mail = new PHPMailer(true);

header('Content-Type: application/json'); // tell browser it's JSON

$response = [
    'status' => 'error',
    'message' => 'Invalid request.'
];


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get form fields
    $program_event = $_POST['program_event'];
    $location = $_POST['location'];
    $topic = $_POST['topic'];
    $invitation_date = $_POST['invitation_date'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact_number = $_POST['contact'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    try {
        // Server settings
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; 
        $mail->SMTPAuth   = true;
        $mail->Username   = 'zangitmusic@gmail.com'; // 🔥 Your Gmail email address
        $mail->Password   = 'mvmq ertq dmzx mirh';   // 🔥 Gmail App Password (Not your normal password)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        // $mail->Username = 'zangitmusic@gmail.com';  // your email
       // $mail->Password = 'Music@2025';        // your Gmail app password
        // Recipients
        $mail->setFrom('your-email@gmail.com', 'SureshPurohit dot in website'); // 🔥 Your email and name
        $mail->addAddress('zangitmusic@gmail.com', 'SureshPurohit dot in website'); // 🔥 Receiver email and name

        // Content
        $mail->isHTML(true);
        $mail->Subject = "New Invitation Request from $name";
        $mail->Body    = "
            <h3>You have received a new invitation request.</h3>
            <p><strong>Program/Event:</strong> $program_event</p>
            <p><strong>Location/Place:</strong> $location</p>
            <p><strong>Topic:</strong> $topic</p>
            <p><strong>Date of Invitation:</strong> $invitation_date</p>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Contact Number:</strong> $contact_number</p>
            <p><strong>Subject:</strong> $subject</p>
            <p><strong>Message:</strong><br>$message</p>
        ";

        header('Content-Type: application/json');
        
        $mail->send();
        echo json_encode([
            'status' => 'sent',
            'message' => 'Your message has been sent successfully!'
        ]);
        exit;

    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Mailer Error: ' . $mail->ErrorInfo
        ]);
        exit;
    }
}
ob_clean();
echo json_encode($response); // Default error
?>
