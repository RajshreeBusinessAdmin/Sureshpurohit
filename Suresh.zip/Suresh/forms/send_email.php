<?php
// Load PHPMailer
require '../src/PHPMailer.php';
require '../src/SMTP.php';
require '../src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Create PHPMailer instance
$mail = new PHPMailer(true);

try {
    // SMTP Server Configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'snehaljadhav2391@gmail.com';  // your email
    $mail->Password = 'zuob qoms pfqw wpip';        // your Gmail app password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Email settings
    $mail->setFrom('snehaljadhav2391@gmail.com', 'Website Invitation Form');
    $mail->addAddress('support@pharmacupboard.com');  // recipient

    // Collect POST data
    $program_event = $_POST['program_event'] ?? '';
    $location = $_POST['location'] ?? '';
    $topic = $_POST['topic'] ?? '';
    $invitation_date = $_POST['invitation_date'] ?? '';
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $contact = $_POST['contact'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';

    // Email content
    $mail->isHTML(true);
    $mail->Subject = "New Invitation Request: $subject";
    $mail->Body    = "
        <h2>New Invitation Received</h2>
        <p><strong>Program/Event:</strong> $program_event</p>
        <p><strong>Location:</strong> $location</p>
        <p><strong>Topic:</strong> $topic</p>
        <p><strong>Date:</strong> $invitation_date</p>
        <p><strong>Name:</strong> $name</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Contact:</strong> $contact</p>
        <p><strong>Message:</strong><br>$message</p>
    ";

    // Send email
    $mail->send();
    echo 'Mail has been sent successfully!';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
